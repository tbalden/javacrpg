Copyright (C) 2008 tidbit

This 3D model is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this 3D model.

Permission is granted to anyone to use this 3D model for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this 3D model must not be misrepresented; you must not
claim that you created the original 3D model. If you use this 3D model
in a product, an acknowledgment in the product documentation would be
appreciated but is not required.
2. Altered 3D model file versions must be plainly marked as such, and must not be
misrepresented as being the original 3D model.
3. This notice may not be removed or altered from any 3D model file distribution.