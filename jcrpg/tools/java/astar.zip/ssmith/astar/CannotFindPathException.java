package ssmith.astar;

public class CannotFindPathException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	public CannotFindPathException() {
		super();
	}

	public CannotFindPathException(String s) {
		super(s);
	}

}
